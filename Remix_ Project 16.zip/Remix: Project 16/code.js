var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","684521d6-33f7-4692-b38e-e5e0ae1bea6b","22f32c8d-4cd1-40c4-9888-27a8b3d6dd96"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":12,"version":"0AKfvGhgzxVu4gR9EK4JX0391mZBTSys","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png","frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":4,"version":"OGlmAlYFsDBq.NocNMUP2kcNtv6Wn7BR","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"2GTwYshgazwpK69gF7UPpedQc7kLJ15w","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"684521d6-33f7-4692-b38e-e5e0ae1bea6b":{"name":"groundGrass_1","sourceUrl":null,"frameSize":{"x":808,"y":71},"frameCount":2,"looping":true,"frameDelay":12,"version":"QZOyr3VV822HjGXWVDX8yeKoc3xRsDWM","loadedFromSource":true,"saved":true,"sourceSize":{"x":808,"y":142},"rootRelativePath":"assets/684521d6-33f7-4692-b38e-e5e0ae1bea6b.png"},"22f32c8d-4cd1-40c4-9888-27a8b3d6dd96":{"name":"cloud_1","sourceUrl":"assets/api/v1/animation-library/gamelab/BeluqVwHb2a.yvYLoxkNH0HWitQlKDF9/category_environment/cloud.png","frameSize":{"x":260,"y":134},"frameCount":1,"looping":true,"frameDelay":2,"version":"BeluqVwHb2a.yvYLoxkNH0HWitQlKDF9","loadedFromSource":true,"saved":true,"sourceSize":{"x":260,"y":134},"rootRelativePath":"assets/api/v1/animation-library/gamelab/BeluqVwHb2a.yvYLoxkNH0HWitQlKDF9/category_environment/cloud.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


/*var ground = createSprite(200,380,400,20);
ground.setAnimation("groundGrass_1");
ground.x = ground.width /2;
ground.scale = 0.99;*/

var score = 0;

var play = 1;
var end = 0;
var gameState = play;

var ground = createSprite(200,375,400,50);
ground.shapeColor = "#3CB371";

var invisibleG = createSprite(200,388,400,25);
invisibleG.visible = false;

var monkey = createSprite(75,325,101,10);
monkey.setAnimation("monkey");
monkey.scale = 0.1;

var bg = createGroup();
var og = createGroup();

function draw() {
  
  background(176,224,230);
  
  monkey.collide(invisibleG);
  
  if(gameState == play) {
    
    for(var i = 0;i<bg.length;i++ ){
      
    
    if(bg.isTouching(monkey)){
      bg.get(i).destroy();
      score = score + 1;
    }
    }
    if(keyWentUp("space") && monkey.y >= 270) {
      monkey.velocityY = -12 ;
    } 
    monkey.velocityY = monkey.velocityY + 0.5;
    spawnO();
    spawnB();
    if(monkey.isTouching(og)) {
    gameState = end;
    }
  }
  else if(gameState === end) {
    bg.setVelocityXEach(0);
    bg.destroyEach();
    og.setVelocityXEach(0);
    og.destroyEach();
    textSize(18);
    textFont("Georgia");
    textStyle(BOLD);
    text("congrats, you scores a " + score +"!", 125,130);
    text("click 'r' to play again", 125,160);
    if(keyWentDown("r")) {
      gameState = play;
      score = 0;
    }
  }
    
    ground.velocityX = -3;
    if (ground.x < 199) {
      ground.x = ground.width/2;
    }
    
    textSize(18);
    textFont("Georgia");
    textStyle(BOLD);
    text("Score: "+ score, 125, 100);
    
    /*if(score%10 == 0 && score > 0){
      monkey.scale = monkey.scale + 0.1;
    }*/
    
  drawSprites();
}

function spawnB() {
  if(World.frameCount % 80 === 0) {
    var banana1 = createSprite(400,365,10,40);
    banana1.velocityX = -5;
    banana1.setAnimation("Banana");
    banana1.scale = 0.05;
    banana1.lifetime = 89;
    bg.add(banana1);
  }
  if(World.frameCount % 100 === 0) {
    var banana2 = createSprite(400,200,10,40);
    banana2.velocityX = -5;
    banana2.setAnimation("Banana");
    banana2.scale = 0.05;
    banana2.lifetime = 89;
    bg.add(banana2);
  }
}

function spawnO() {
  if(World.frameCount % 300 === 0) {
    var obstacle = createSprite(400,350,10,40);
    obstacle.velocityX = -5;
    obstacle.setAnimation("Stone");
    obstacle.scale = 0.15;
    obstacle.lifetime = 105;
    og.add(obstacle);
  }
}
 




  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
